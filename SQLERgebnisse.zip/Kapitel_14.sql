select empno "Nummer", ename "Name" from emp;

select ename "Name", 12*(sal+500) "Jahresgehalt" from emp;

select ename || ' ist von Beruf ' || job "Wer macht was:" from emp;

select distinct job, deptno from emp;

select distinct loc from dept4;