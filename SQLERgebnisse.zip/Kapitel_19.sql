/*select function(spaltenname) from table;*/

select avg(sal), max(sal), min(sal), sum(sal)
    from emp
    where job = 'SALESMAN';
    
select min(ename), max(ename), Min(hiredate), max(hiredate) from emp;

select count(*), count(comm) from emp;

select avg(coalesce(comm, 0)) from emp;

select job, deptno, round(avg(sal), 2) durchschnitt 
    from emp
     where job in('CLERK', 'MANAGER')
    GROUP BY deptno, job
    having avg(sal) > 1000
    order by deptno, durchschnitt;