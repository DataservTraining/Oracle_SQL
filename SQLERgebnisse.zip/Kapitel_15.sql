select ename, job from emp where ename like '_LL%';

select loc, dname from dept where dname like '%*_%' escape '*';

select * from dept;

select ename, sal from emp where sal between 1000 and 2000;

select deptno, loc, dname from dept where deptno in (10,30);

select * from emp where comm is not null;

select ename, sal, job 
    from emp
    where job='CLERK'
    and (sal < 1100
    or job = 'MANAGER');
    
select ename, job, sal
    from emp
    ORDER BY sal desc;