/*DECLARE

BEGIN

END; 

create table einheit (
    einheit_kurz varchar2(10),
    bezeichnung varchar2(40));
    
alter table einheit add constraint pk_einheit primary key(einheit_kurz);
    
delete from einheit;*/

set serveroutput on;


/*
DECLARE
    v_einheit_kurz einheit.einheit_kurz%TYPE;
    v_bezeichnung varchar2(40);
   
BEGIN
    v_einheit_kurz := 'cm';
    v_bezeichnung := 'Zentimeter';
    insert into einheit (einheit_kurz, bezeichnung)
            values (v_einheit_kurz, v_bezeichnung);
EXCEPTION when DUP_VAL_ON_INDEX then
    dbms_output.put_line('Einheit schon vorhanden, Bezeichnung wurde ge�ndert');
    update einheit set bezeichnung = v_bezeichnung where einheit_kurz = v_einheit_kurz;
END;

*/

DECLARE 
     v_zeile einheit%ROWTYPE;
BEGIN
    select *  into v_zeile
        from einheit where einheit_kurz = 'cm';
        
    dbms_output.put_line('Kurzbezeichnung der Einheit: ' || v_zeile.einheit_kurz);
    dbms_output.put_line('Bezeichnung: ' || v_zeile.bezeichnung);
END;
