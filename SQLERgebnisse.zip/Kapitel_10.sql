create TABLE testtabelle (
    id integer,
    name varchar(25),
    gehalt NUMBER(8,2));
    
    
desc testtabelle;

create table testtabelle2 as select * from testtabelle;

desc testtabelle2;

alter table testtabelle2 add test varchar(2);

alter table testtabelle2 MODIFY test varchar(10) DEFAULT ('Hallo');

alter table testtabelle2 drop column test;

alter table testtabelle2 rename to testtabelle3;

alter table testtabelle3 rename column name to nachname;

rename testtabelle3 to testtabelle2;

drop table testtabelle2 purge;

flashback table testtabelle2 to before drop;

TRUNCATE table testtabelle;
