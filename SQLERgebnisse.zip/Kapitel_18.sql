select empno, ename, loc, dname 
    from emp, dept
    where emp.deptno = dept.deptno
    and emp.deptno=20;
    
select empno, ename, emp.deptno, loc, dname 
    from emp inner join dept
        on emp.deptno = dept.deptno
    where emp.deptno = 20;
    
select empno, ename, deptno, loc, dname 
    from emp NATURAL JOIN dept
    where deptno = 20;
    
select e.ename , s.grade
    from emp e, salgrade s
    where e.sal between s.losal and s.hisal
    and e.deptno = 10;
    
select e.ename, s.grade 
    from emp e inner join salgrade s
        on e.sal between s.losal and s. hisal
    where e.deptno = 10;
    
select e.ename, e.deptno, d.dname
    from emp e right outer join dept d
        on e.deptno = d.deptno;

select e.ename, e.deptno, d.dname
    from empnew e left outer join dept d
        on e.deptno = d.deptno;

select e.ename, e.deptno, d.dname
    from empnew e, dept d
        where e.deptno = d.deptno(+);

select e.ename, e.deptno, d.dname
    from empnew e full outer join dept d
        on e.deptno = d.deptno;
        
select mi.ename "Mitarbeiter", ma.ename "Manager" 
    from emp mi inner join emp ma
        on mi.mgr = ma.empno;
        
select e.ename, d.loc, s.grade
    from emp e, dept d, salgrade s
    where e.deptno = d.deptno
    and e.sal between s.losal and s.hisal
    and e.ename = 'KING';

select e.ename, d.loc, s.grade
    from emp e inner join dept d
        on e.deptno = d.deptno
        inner join salgrade s
        on e.sal between s.losal and s.hisal
    where e.ename = 'KING';
        
insert into empnew values (7839,'Duck','MANAGER',NULL,'17.11.1981',50000,NULL,null);