create table test (
    id integer PRIMARY KEY,
    name varchar2(20) Not null,
    x INTEGER UNIQUE);
    
desc test;
    
create table test2 (
    id integer,
    name varchar2(20),
    x INTEGER,
    constraint pk_test primary key (id),
    constraint x_unique unique(x));
    
    alter table test2 MODIFY name not null;
desc test2;

create table dept2(
id number primary key,
bez varchar2(20));


create table emp2(
    empno number,
    dept_id number,
    CONSTRAINT fk_emp2_dept2 FOREIGN key (dept_id) REFERENCES dept2(id));
   
desc emp2; 

create table emp3(
    empno number,
    dept_id number);
    
alter table emp3 add constraint fk_emp3_dept2 FOREIGN KEY (dept_id) REFERENCES dept2(id);

create table dept3 (
id number primary key,
bez varchar2(20),
CONSTRAINT check_id CHECK (id between 10 and 99));

alter table dept3 DISABLE CONSTRAINT check_id CASCADE;

alter table dept3 ENABLE CONSTRAINT check_id;

alter table dept3 drop CONSTRAINT check_id;