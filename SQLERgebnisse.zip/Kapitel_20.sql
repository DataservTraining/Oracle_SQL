/*select spalte 
    from tabelle
    where wert op (select spalte from tabelle);
    */
    
select ename, sal 
    from emp
    where sal > (select sal from emp where ename = 'JONES');
    
select ename, sal, job
    from emp
    where sal < any(select sal from emp where job = 'CLERK')
    and job != 'CLERK';
    
select sal from emp where job = 'CLERK';

select dname from dept
    where exists (select * from emp 
                            where emp.deptno = dept.deptno
                            and comm is not null);
                            
select distinct dname 
        from dept d inner join emp e
        on d.deptno = e.deptno
        where comm is not null;
        
select empno, ename, sal, deptno
    from emp o
    where sal > (select avg(sal) from emp i
                    where o.deptno = i.deptno);
                    
select ename, deptno, sal
    from emp
    where (deptno, sal) in (select deptno, sal from emp where ename ='MARTIN')
    and ename != 'MARTIN';
    
select ename from emp
    where empno not in (select Coalesce(mgr, 0) from emp);
    
    select mgr from emp;
    
select a.ename, a.sal, a.deptno, b.salavg
    from emp a, (select deptno, avg(sal) salavg
                        from emp 
                        group by deptno) b
    where a.deptno = b.deptno
    and a.sal > b.salavg;
                    
                    