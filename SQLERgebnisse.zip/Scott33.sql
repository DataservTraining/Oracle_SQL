declare 
    function einheit_existiert (p_einheit_kurz in varchar2) return boolean is 
        v_anzahl pls_integer; 
    begin 
        select count(*)into v_anzahl from einheit where einheit_kurz = p_einheit_kurz; 
        return v_anzahl > 0; 
    end; 
    
    begin 
        if not einheit_existiert ('qm') then 
            insert into einheit (einheit_kurz, bezeichnung) values ('qm', 'QubikMeter'); 
        end if; 
    end;