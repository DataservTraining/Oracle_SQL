select instr('HERRMANN', 'M') from Dual;

select initCap(ename) from emp;

select lower(ename) from emp;

select upper('hallo welt') from dual;

select concat('Herrman', ' Meier') from dual;

select ename, length(ename) from emp;

select ename, substr(ename, 2, 4) from emp;

select rpad(ename, 10, '*') from emp;

select trim('H' from 'HERRMANN') from dual;

select trim('H' from (trim('*' from '****HERRMANN***'))) from dual;

select Rtrim('****HERRMANN***', '*H') from dual;

select ltrim('*', '****HERRMANN***') from dual;
select Rtrim('****HERRMANN***', '*H') from dual;
select Ltrim('****HERRMANN***', '*H') from dual;

select ename, concat(ename, job), length(ename), instr(ename, 'A')
    from emp
    where lower(substr(job, 1, 4)) = 'pres';
    
select round(73545.6777, 0) from dual;

select trunc(73545.6777, 3) from dual;

select mod(1600, 300) from dual;

select sysdate from dual;

select SYSDATE + 2,
       LAST_DAY(SYSDATE) "Last" from dual;
       
select ename, hiredate, trunc(sysdate-hiredate, 0) from emp;

select ename, hiredate, round(months_between(sysdate, hiredate), 0) "Monate" from emp ;

select add_months(sysdate, 2) from dual;

select next_day(sysdate, 'Dienstag') from dual;

select trunc(sysdate, 'month') from dual;

select add_months(to_date('24.12.2021'), 3) from dual;

select ename, sal, comm, sal+ NVL(comm, 0) from emp;

/*select ename, sal, comm, sal+ isNull(comm, 0) from emp;*/

select ename, sal, comm, sal+ Coalesce(comm, 0) from emp;

select ename, sal, job, 
        case job
        when 'SALESMAN' then sal*1.2
        when 'CLERK' then sal*1.3
        when 'MANAGER' then sal*1.05
        else sal
        end "neues Gehalt"
        from emp;

create table empNew as select * from emp;

update empNew a set sal = (select case job
        when 'SALESMAN' then sal*1.2
        when 'CLERK' then sal*1.3
        when 'MANAGER' then sal*1.05
        else sal
        end from empNew where empno = a.empno);
        
select * from empNew;


select ename, sal, decode(job, 'SALESMAN', sal*1.2, 'CLERK', sal*1.3, 'MANAGER', sal*1.05, sal) "neues Gehalt" from emp;