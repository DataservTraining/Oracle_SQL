//to_char(zahl/datum [,Formatierung])

select to_char(sysdate, 'fmWW". Kalenderwoche: "Day" der "DD. Month YYYY HH24:Mi:SS') from dual;

select to_char(sysdate, 'fmWW". Kalenderwoche: "Day" der "DD. Month YYYY HH24:Mi:SS') from dual;

select LPAD(to_char(1232.35445, '9G999D99L'), 15, '0') from dual;

select to_char(1232.35445, '9G999D99L'), LPAD(to_char(1232.35445, '9G999D99L'), 15, '0') from dual;

select lpad('test', 15, '0') from dual;

select to_Date('Juli 28 2021', 'Month DD YYYY' ) from dual;
 select TO_NUMBER('2.00', '9.99') "Value"
   FROM DUAL;
   
select ename "Name", coalesce(to_char(mgr), 'kein Manager') "Manager" from emp ;
