set serveroutput on;
/*
Declare
v_einheit_kurz varchar2(10);
v_bezeichnung varchar2(40);
begin
v_einheit_kurz := 'cm';
v_bezeichnung := 'centimeter';
dbms_output.put('v_einheit_kurz: ' || v_einheit_kurz);
dbms_output.put_line('      v_bezeichnung: ' || v_bezeichnung);
insert into einheit values (v_einheit_kurz, v_bezeichnung);

exception when DUP_VAL_ON_INDEX then
    dbms_output.put_line('Schl�ssel bereits vorhanden! Datensatz ge�ndert');
    update einheit set bezeichnung = v_bezeichnung where einheit_kurz =v_einheit_kurz;
end;
*/

declare 
    v_datensatz emp%rowtype;
    v_sal emp.sal%type;
    begin
    select * into v_datensatz
        from emp where empno=7839;
    SELECT sal into v_sal
    from emp where empno = 7839;
    if lower(v_datensatz.ename) = 'kong' then
        dbms_output.put_line('' ||v_datensatz.ename);
    else
        dbms_output.put_line('war doch nicht KING');
    end if;
    dbms_output.put_line('' || v_sal);
    end;