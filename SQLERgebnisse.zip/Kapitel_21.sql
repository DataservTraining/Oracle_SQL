

create or replace view abt10withDept
as select empno, ename, job, deptno
    from emp
    where deptno = 10
    with CHECK OPTION;
    
    
insert into abt10withdept values(9002, 'Mitarbeit', 'SALESMAN', 20);

delete from emp where empno >=9000;
    
select * from abt10;

insert into abt10 values(9000, 'Mitarbeit', 'SALESMAN');

create or replace view abt10new
as select empno, ename, job
    from empnew
    where deptno = 10;

create view abt10new
as select empno, ename, job, deptno
    from empnew
    where deptno = 10;
    
drop view abt10new;
    
delete from empnew where empno=7839;
    
insert into abt10new values(9003, 'Mitarbeit', 'SALESMAN');

alter table empnew add constraint pk_emp primary key(empno); 

create or replace view abt20 ("MA-Nummer", "Name", "Abteilungsnummer")
as select empno, ename, job
    from emp
    where deptno = 20;
    
select * from abt20;

create or replace view abt202 
as select empno "Ma-Nr.:", ename "Name", job "Beruf" 
    from emp
    where deptno = 20;
    
select * from abt202;

create or replace view dept_sum_vu (name, minsal, maxsal, avgsal)
as select d.dname, min(e.sal), max(e.sal), round(avg(e.sal), 0)
    from emp e inner join dept d
    on e.deptno = d.deptno
    group by d.dname;
    
select minsal from dept_sum_vu; 