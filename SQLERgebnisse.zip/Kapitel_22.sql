create SEQUENCE dept_deptno 
    INCREMENT by 10
    start with 60
    maxvalue 100
    nocache
    nocycle;
    
    select * from dept order by deptno;
    
select sequence_name, min_value, max_value, increment_by, last_number from user_sequences;
select * from user_sequences;

select currval from user_sequences;

insert into dept values(dept_deptno.nextval, 'MARKETING', 'SAN DIEGO');

insert into dept values(dept_deptno.nextval, 'MARKETING', 'N�rnberg');

alter sequence dept_deptno  
    INCREMENT by 10
    maxvalue 9999
    nocache
    nocycle;
    
create unique index emp_ename_idx on emp(ename);
drop index emp_ename_idx;

create public synonym emp_syn2 for c##scott.emp;

drop public synonym emp_syn;
