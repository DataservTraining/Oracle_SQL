create table kunden (
id integer primary key,
name VARCHAR2(10));

insert into kunden values(1, 'Meier');

create table vorgang (
vid integer primary key,
bezeichnung varchar2(20),
kunde integer,
constraint fk_vorgang_kunde foreign key(kunde) REFERENCES kunden(id));

create table notizen(
nid integer primary key,
inhalt varchar2(50),
vid integer,
constraint fk_notiz_vorgang foreign key(vid) REFERENCES vorgang(vid));

insert into vorgang values (1, 'erster Vorgang', 1);

insert into notizen values (1, 'blabla', 1);

select * from kunden;

select * from vorgang;

select * from notizen;

delete from vorgang where vid = 1;

alter table notizen drop constraint fk_notiz_vorgang;
alter table notizen add constraint fk_notiz_vorgang foreign key(vid) REFERENCES vorgang(vid) on delete cascade;