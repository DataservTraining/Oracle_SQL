declare 
    v_anzahl pls_integer; 
    procedure neue_einheit ( p_einheit_kurz in varchar2, p_bezeichnung in varchar2) is 
    begin
        insert into einheit (einheit_kurz, bezeichnung) values (p_einheit_kurz, p_bezeichnung); 
    end; 
    
    begin 
        select count(*)into v_anzahl from einheit where einheit_kurz = 'm'; 
        if v_anzahl = 0 then 
            neue_einheit ('m', 'Meter'); 
        end if; 
    end;
    
    select * from einheit;