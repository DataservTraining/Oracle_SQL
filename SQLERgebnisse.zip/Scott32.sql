create or replace procedure print_return_date (p_start_date in date, p_day_amount in number)
as
    l_end_time varchar2(25);
begin
        l_end_time := to_char(next_day(p_start_date + p_day_amount, 'MON'), 'DD.MM.YYYY');
        dbms_output.put_line('R�ckgabe am ' || l_end_time);
    exception when others then
        dbms_output.put_line('Fehler: ' || sqlerrm);
end print_return_date;