create table einheit (
    einheit_kurz varchar2(10) primary key,
    bezeichnung varchar2(40));
    
    drop table einheit;
    
    select * from einheit;
    