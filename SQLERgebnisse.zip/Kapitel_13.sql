insert into dept2 values (1, 'eintrag 1');

insert into dept2 (id) values (2);

insert into dept2 (bez, id) values ('test3', 4);

insert into dept2 (bez, id) values ('"&"bezeichnung', 70);

Update dept2 set bez='falscher Wert' where bez = 'neuer Wert'; 

alter table dept2 add spalte2 varchar2(25);

update dept2 set bez='testwert', spalte2='irgendwas' where id=3;

update dept2 set id=10 where id = 3;

delete from dept2 where id > 4;

SAVEPOINT a;
commit;
delete from dept2;
ROLLBACK to a;
insert into emp values (7839, 'KING', 'PRESIDENT', null, '17.11.81', 5000, null, 10);
insert into dept values (10, 'ACCOUNTING', 'NEW YORK');

select * from salgrade;
